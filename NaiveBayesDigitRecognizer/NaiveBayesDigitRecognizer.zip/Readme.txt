The MIT License (MIT), Copyright © Omid Saremi 2013 

* This code has been tested with Python 2.7.5. It might not work with earlier versions. 
* To run this code on Mac, open up a terminal. Change directory to this Unzipped folder and simply enter "python NaiveBayesDigitRecognizer.py" at the prompt. 
* Dataset is the text file called "digits.txt" in this folder. 
* The text file "semeion.names.txt" describes the data in details; how it was collected and what its attributes are. 
* Dataset was taken from UCI Machine Learning repository: http://archive.ics.uci.edu/ml/datasets/Semeion+Handwritten+Digit

